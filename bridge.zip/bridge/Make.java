package org.techtalk.bridge;

public class Make implements WorkShop {

    @Override
    public void make() {
        System.out.println("Making...");
    }
}
