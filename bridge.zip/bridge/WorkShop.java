package org.techtalk.bridge;

interface WorkShop {
     void make();
}
