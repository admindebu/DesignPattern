package org.techtalk.bridge;

public class Assemble  implements WorkShop{
    @Override
    public void make() {
        System.out.print("..Adding.. ");
        System.out.println("Assembled");
    }
}
