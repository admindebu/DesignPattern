package org.techtalk.bridge;

public class Main {

    public static void main(String[] args) {

        Vehicle bmw = new Car(new Make(), new Assemble());
        bmw.manufacture();

        Vehicle honda = new Bike(new Make(), new Assemble());
        honda.manufacture();
    }
}
