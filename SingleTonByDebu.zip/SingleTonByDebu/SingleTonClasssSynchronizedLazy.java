//Create Singleton Class so that Thread Safe ?

package comd.techtalk.interview;

public class SingleTonClasssSynchronizedLazy {

	private static SingleTonClasssSynchronizedLazy uniqueInstance;

	private String name;

	private SingleTonClasssSynchronizedLazy() {

	}

	public static synchronized SingleTonClasssSynchronizedLazy getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new SingleTonClasssSynchronizedLazy();
		}
		return uniqueInstance;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

// just add the synchronized word on the getInstance method