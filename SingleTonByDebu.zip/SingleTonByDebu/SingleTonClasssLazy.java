 //Create Singleton Class Lazy ?
// As we are creating Object inside the getInstance method of the class : 
package comd.techtalk.interview;

public class SingleTonClasssLazy {

	SingleTonClasssLazy 

	private String name;

	private SingleTonClasssLazy () {

	}

	public static SingleTonClasssLazy getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new SingleTonClasssLazy ();
		}
		return uniqueInstance;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}