//4. Creating Singleton class Double CHeck Locking?
// Best way for Thread Safety


package comd.techtalk.interview;

public class SingleTonClassDoubleCheckingLock {

	private volatile static SingleTonClassDoubleCheckingLock uniqueInstance;

	private String name;

	private SingleTonClassDoubleCheckingLock() {

	}

	public static SingleTonClassDoubleCheckingLock getInstance() {
		if (uniqueInstance == null) {

			synchronized (SingleTonClassDoubleCheckingLock.class) {

				if (uniqueInstance == null) {
					uniqueInstance = new SingleTonClassDoubleCheckingLock();
				}
			}

		}
		return uniqueInstance;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}