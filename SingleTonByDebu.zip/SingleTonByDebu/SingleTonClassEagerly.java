//Create Singleton Class Eagerly?

// Creating Object at the top : this is better than Lazy
package comd.techtalk.interview;

public class SingleTonClassEagerly {

	private static SingleTonClassEagerly uniqueInstance = uniqueInstance = new SingleTonClassEagerly();

	private String name;

	private SingleTonClassEagerly() {

	}

	public static SingleTonClassEagerly getInstance() {
		return uniqueInstance;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}