package org.techtalk.facade;

public class ComputerFacade {
   
	private Monitor display;
	private CPU processor;
    private Memory ram;
    private HardDrive hd;
   

    public ComputerFacade(Monitor display,CPU processor, Memory ram, HardDrive hd) {
    	this.display =  display;
        this.processor = processor;
        this.ram = ram;
        this.hd = hd;
    }

    public void start() {
    	display.turnOn();
        processor.initializing();
        ram.load(7, hd.read(3456, 89));
        processor.jump(132);
        processor.execute();


    }
}
