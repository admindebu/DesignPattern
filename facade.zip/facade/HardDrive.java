package org.techtalk.facade;

public class HardDrive {
    public byte[] read(long Iba, int size) {
        return new byte[]{'T', 'D'};
    }
}
