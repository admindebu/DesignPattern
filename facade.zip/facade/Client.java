package org.techtalk.facade;

public class Client {

    public static void main(String[] args) {
    	
        Monitor display = new Monitor();
        CPU cpu = new CPU();
        Memory memory = new Memory();
        HardDrive hd = new HardDrive();


        ComputerFacade computerFacade = new ComputerFacade(display,cpu, memory, hd);
        computerFacade.start();
    }
}
