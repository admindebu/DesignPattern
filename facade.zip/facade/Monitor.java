package org.techtalk.facade;

public class Monitor {

	public void turnOn() {
		System.out.println("Monitor On ....");
	}

	public void turnOff() {
		System.out.println("Monitor Off ....");
	}

}